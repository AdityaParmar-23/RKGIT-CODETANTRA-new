
// write your code here 
public class ReveresedArguments{
	public static void main(String[] args){
		//String a1=args[3];
		//String a2=args[2];
		//String a3=args[1];
		//String a4=args[0];
		//String a5=a1+a2+a3+a4;
		//System.out.println(a5);
		System.out.println(args[3]+args[2]+args[1]+args[0]);
	}
}